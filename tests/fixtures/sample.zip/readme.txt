Sample archive used by the end-to-end tests.
